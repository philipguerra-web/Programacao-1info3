console.log("primiera linha \n segunda linha");
console.log("o meu nome é 'Philip'");
console.log('o meu apelido é "PH"');
console.log(`a multiplicação de 5 por 3 é ${5*3}`);
console.log("o" +" meu" + " nome" + " é" + " Philip")