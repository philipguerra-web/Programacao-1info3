console.log( true && true);
console.log( true && false);
console.log( true || false);
console.log( false || false);
console.log(!true);
console.log( 5 > 3 && 3 ==2);
console.log( 5 > 3 || 3 ==2);
console.log( 3==3 && "matheus" == "matheus");
console.log("felipe" == "joão" || false);