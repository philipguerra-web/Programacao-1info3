console.log(Infinity);
console.log(-Infinity);
console.log(NaN);
console.log(typeof infinity);
console.log(typeof -Infinity);
console.log(typeof NaN);