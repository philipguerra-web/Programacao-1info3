var nome = prompt("digite seu nome");
console.log("oi meu nome é Philip");
console.log("meu apelido é PH");
console.log("meu Deus eu queria muito um café quentinho!");