console.log (5 * null) // 0
console.log("5" - 3) //2
console.log("5" + 1)//51(concatenou)
console.log("dois" * "três"); // NaN