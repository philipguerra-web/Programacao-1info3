console.log(true? 1:2);
console.log( false ? 'falso' : 'verdadeiro');
console.log(5>2? 'È sim' : 'È não');
console.log( "Mathews"== "Mathews"?"Óla, Mathews!" : "Não é o Mathews" );