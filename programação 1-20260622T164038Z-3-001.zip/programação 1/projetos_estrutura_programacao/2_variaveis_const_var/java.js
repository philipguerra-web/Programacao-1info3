var name = 'philip';
const ip = "140.127.339";
const sobrenome = 'guerra';

console.log(name);
console.log(sobrenome);
console.log(ip);

console.log(name + " " + (sobrenome));

ip = "67.67.67" //esse é pra dar erro mesmo
//constante ip = "140.127.339";obs: constante não se altera o valor