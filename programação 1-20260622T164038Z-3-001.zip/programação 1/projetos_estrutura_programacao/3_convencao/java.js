let nome1 = 'teste1';
let $nome2 = 'teste2';
let _nome3 = 'teste3';
let Nome4 = 'teste4';
let meuNome5 = 'teste5';
let nome6 = 'teste6';