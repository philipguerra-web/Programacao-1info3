let A = 5;
let B = 10;
let c = A + B;
console.log(c);
alert(`c = 15`);