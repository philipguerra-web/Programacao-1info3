
const max_height = 190
console.log(`Matheus tem ${max_height} centimetros de altura no máximo`);
