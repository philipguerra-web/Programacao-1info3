let num = prompt("infome um numero");

let dubleNum = num * 2;

alert(dubleNum);