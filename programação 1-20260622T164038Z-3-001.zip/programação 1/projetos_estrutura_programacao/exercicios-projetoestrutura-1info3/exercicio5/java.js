let curso ="Tecnico em informatica para internet";
let inst = "IFC";
let semestre = "1°";
console.log(`Eu estudo no ${inst}, estou cursando ${curso} e estou no ${semestre} semestre`);