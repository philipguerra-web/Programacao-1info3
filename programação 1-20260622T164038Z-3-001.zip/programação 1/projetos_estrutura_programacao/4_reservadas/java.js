let functionteste = 'teste3';
let function1 = 'teste4';

console.log(functionteste);
console.log(function1);

//let if = 'teste1';
//let function = 'teste2";