let idade = prompt ('qual a sua idade?');
console.log(idade);

let nome = prompt ('qual o seu nome?');
console.log(nome);

nome = prompt( 'você está mentindo?');