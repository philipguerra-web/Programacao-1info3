let name = "Philip";
console.log(name);
console.log(`meu nome  é  ${name}`)

let laranja = 5;
console.log(laranja * laranja);

name = "joão";
console.log(name);
console.log(`meu nome é ${name}`);

laranja = 67;
console.log(laranja + laranja);
console.log(laranja % laranja);

laranja = "Laranjas";
console.log(laranja);

