let maior = Math.max (1,10,100,1000); //max = maior
console.log(maior);

let menor = Math.min (5,10,15,20,25); //min = menor
console.log (menor);

let arredondar = Math.round (3.14567568); //round = arrendondar
console.log(arredondar);

let arredondarParaCima = Math.ceil (3.14567568); //ceil = arredondar pra cima
console.log(arredondarParaCima);