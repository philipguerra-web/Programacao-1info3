let nome = 'Philip'
let idade = 15
console.log( `meu nome é ${nome}`);
console.log(`e eu tenho ${idade} anos`);