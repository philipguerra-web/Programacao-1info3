let larguraT = parseFloat(prompt("qual é a largura do tijolo?(em cm)"));
let alturaT = parseFloat(prompt("qual a altura do tijolo?(em cm)"));

let alturaP = parseFloat(prompt("qual a altura da parede?(em cm)"));
let larguraP = parseFloat(prompt("qual a largura da parede?(em cm)"));

let dTijolo = larguraT * alturaT;
let dParede = larguraP * alturaP;

let numTijolo = (dParede -(dParede * 3/100)) / dTijolo;

alert(" o numero de tijolos necessários para construir tal parede vai ser de " + numTijolo.toFixed(2));