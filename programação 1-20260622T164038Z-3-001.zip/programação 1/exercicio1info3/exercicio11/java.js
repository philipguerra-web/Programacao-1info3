let gado = parseFloat(prompt("quantas cabeças de gado o fazendeiro tem?"));
let herdeiros = parseFloat(prompt("quantos herdeiros o fazendeiro tem?"));
let 