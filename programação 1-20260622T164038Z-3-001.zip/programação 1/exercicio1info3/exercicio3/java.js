let precoQuilo = parseFloat (prompt("digite o valor do quilo(R$): "));
let quantidade = parseFloat(prompt("digite a quantidade consumida (em kg):"));
let valorFinal = precoQuilo * quantidade;
alert("o valor a ser pago vai ser: R$" + valorFinal.toFixed(2));