let tempoHrs = parseFloat(prompt("quantas horas ele viajou de carro?"));
let velocidade = parseFloat(prompt("qual foi a velocidade que ele percorreu? (km/h)"));
let consumo = parseFloat(prompt("qual foi o gasto de gasolina dessa viajem?(km por litro)"));
let preco = parseFloat(prompt("qual é o preço por litro da gasolina?(R$ por litro)"));

let distância = tempoHrs * velocidade;
let gasto = distância / consumo;
let custo = (distância * preco);

alert("a distância do trajeto foi de " + distância.toFixed(1) + " km");
alert("ele gastou " + gasto.toFixed(1) + " litros por km");
alert("o gasto total que ele teve nessa viajem foi de R$" + custo.toFixed(1) );

