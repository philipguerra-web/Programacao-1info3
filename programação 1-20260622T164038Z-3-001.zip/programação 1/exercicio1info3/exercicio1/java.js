let precoQuilo = 28.00
let peso = parseFloat(prompt("digite o peso do seu prato (em kg):"));
let valor = peso * precoQuilo;
alert ("o valor a pagar é : R$ " +valor.toFixed(2));