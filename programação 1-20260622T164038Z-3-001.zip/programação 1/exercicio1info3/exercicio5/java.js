let pedreiroH = parseFloat(prompt("quantas horas foram contratadas pelo pedreiro?"));
let pintorH = parseFloat(prompt("quantas horas foram contratadas pelo pintor?"));

let custoPd = pedreiroH * 20.00
let custoPt = pintorH * 16.00
let custoFinal = custPd + custoPt

alert("o custo total dessa obra vai irá ser de R$" + custoFinal.toFixed(2)+ " " + "o custo do pedreiro separadamente do pintor será R$" + custoPd.toFixed(2) + " " + "e o do pintor será R$" + custoPt.toFixed(2));