let valorFinal = parseFloat(prompt("insira o valor"));
let precokg = parseFloat (prompt("insira o precço do quilo"));

let quiloConsumido = valorFinal / precokg;
 
alert("o quilo consumido foi :" + quiloConsumido.toFixed(2) + "kg");