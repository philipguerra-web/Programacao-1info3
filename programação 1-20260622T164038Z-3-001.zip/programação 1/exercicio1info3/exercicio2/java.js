let precoProduto = parseFloat (prompt("informe o preço do produto"));

let Valorpago = parseFloat (prompt("pague o produto"));

let troco = precoProduto - Valorpago;

alert ("seu troco é : R$" +troco.toFixed(2));
