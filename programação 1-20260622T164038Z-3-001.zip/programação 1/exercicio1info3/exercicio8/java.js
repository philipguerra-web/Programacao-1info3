let produto = parseFloat(prompt("insira o valor do produto"));
let valorPago = parseFloat(prompt("insira o valor do produto após o desconto"))
let desconto = parseFloat((produto - valorPago)/produto)*100;
alert(`seu desconto foi de ${desconto}%`);                                         