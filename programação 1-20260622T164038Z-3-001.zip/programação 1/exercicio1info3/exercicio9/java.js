let produto = parseFloat(prompt("insira o valor do produto"));
let valorFinal = produto * 0.05
alert("seu valor final será de R$" + valorFinal.toFixed(2));

