//valores de entrada
let Ndolar = parseFloat(prompt("insira a quantia de dolares em seu cofre"));
let reais = parseFloat(prompt("quantos reais tem um dolar atualmente?"));

//processamento dos valores
let valorFinal = Ndolar / reais

//valor de saida
alert("você tem R$" + valorFinal.toFixed(2) + " em seu cofre");