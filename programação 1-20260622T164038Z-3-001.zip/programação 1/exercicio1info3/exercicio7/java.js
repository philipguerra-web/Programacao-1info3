let nota1 = parseFloat(prompt("insira o valor de sua primeria nota"));
let nota2 = parseFloat(prompt("insira o valor de sua segunda nota"));
let nota3 = parseFloat(prompt("insira o valor de sua terceira nota"));

let peso1 = 2;
let peso2 = 3;
let peso3 = 5;

let media = (nota1*2 + nota2 * 3 + nota3 * 5) / (10);

alert( "a sua nota media ponderada é " + media.toFixed(1));