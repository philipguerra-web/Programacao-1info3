let peso = parseFloat(prompt("qual o seu peso?"));
let pesoGordo = parseFloat(peso + peso * 0.15)
let pesoMagro = parseFloat(peso - peso * 0.20);
alert("seu peso é de " + peso + "kg, se você engordar 15% seu novo peso será de " + pesoGordo + "kg e seu você emagrecer 20% o seu peso será de " + pesoMagro + "kg.");