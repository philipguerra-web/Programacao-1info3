let valor = parseFloat(prompt("qual o valor total do produto?"));
let parcelas = parseFloat(prompt("quantas parcelas foram?"));
let acrescimo = parseFloat(prompt("quantos juros será imposto a cada parcela?"));

let acrescimoPorcento = (acrescimo / 100) * valor;
let valorTotal = valor + acrescimo
let vParcelado = (valorTotal / (parcelas));

alert("o valor do acrescimo foi de R$" + acrescimoPorcento);
alert("o valor total será de R$" +  valorTotal.toFixed(2));
alert("cada parcela irá ser de R$" + vParcelado.toFixed(2));