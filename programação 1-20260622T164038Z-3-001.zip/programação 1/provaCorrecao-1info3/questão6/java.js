let numeroEntrega = parseFloat(prompt("quantas entregas foram realizadas?"));
let tempoMedioEntrega = parseFloat(prompt("quanto tempo em média para cada entrega?(em minutos)"));
let consumoMedio = parseFloat(prompt("quantos litros são consumidos para realizar cada entrega?"));
let preco = parseFloat(prompt("qual o preço da gasolina"));

let tempoTotal = (tempoMedioEntrega/60)*numeroEntrega;
let consumoTotal = consumoMedio*numeroEntrega;
let custoTotal = consumoTotal*preco;
let custoMedio = consumoMedio*preco;

alert("o tempo total que esse entregador trabalha " + tempoTotal.toFixed(2)+" horas");
alert("o cunsumo total foi de " + consumoTotal.toFixed(2) +" litros");
alert("o custo total é de R$" + custoTotal.toFixed(2));
alert("o custo médio para cada entrega foi de R$" + custoMedio.toFixed(2));