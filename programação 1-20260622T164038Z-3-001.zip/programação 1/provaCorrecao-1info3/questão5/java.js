let numeroDiciplinas = parseint(prompt("quantas diciplinas o aluno tem?"));
let horasEstudo = parsefloat(prompt("quantas horas ele estudou por dia, em cada diciplina?"));
let diasEstudo = parseint(prompt("quantos dias ele estudou?"));

let totalHoras = (numeroDiciplinas * horasEstudo);
let totalHorasPeriodo = (totalHoras * diasEstudo);

alert("o aluno estudou um total de " + totalHoras.toFixed(2)+ " horas por dia");
alert("o aluno em todo o período de estudo, estudou um total de " + totalHorasPeriodo.toFixed(2)+ " horas");