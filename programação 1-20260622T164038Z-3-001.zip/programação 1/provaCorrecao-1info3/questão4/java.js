let volueInicial = parseFloat(prompt("quantos litros ainda tem no reservatório?"));
let adicao = parseFloat(prompt("quantos litros serão adicionados por horas?"));
let tempo = parseFloat(prompt("quanto tempo até abastecer?(em horas)"));

let volumeFinal = (volueInicial + (adicao * tempo));
alert("o volume final do reservatório será de " + volumeFinal.toFixed(2) + " litros");