let aulas = parseFloat(prompt("quantas aulas são por dia?"));
let duracao = parseFloat(prompt("quantos minutos dura cada aula?"));
let dias = parseFloat(prompt("quantos dias ele trabalhou?"));

let minutos = (aulas * duracao * dias);
let horas = (minutos / 60);

alert("ele trabalhou um total de " + minutos.toFixed(2) + " minutos");
alert("ele trabalhou um total de " + horas.toFixed(1) + " horas");