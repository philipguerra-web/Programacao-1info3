//entrada
let larguraP = parseFloat(prompt("qual é a largura do piso?(em metros)"));
let comprimentoP = parseFloat(prompt("qual é o comprimento do piso?(em metros)"));

let larguraPeca = parseFloat(prompt("qual é a largura da peça?(em metros)"));
let comprimentoPeca = parseFloat(prompt("qual é o comprimento da peça?(em metros"));

let preco = parseFloat(prompt("qual foi o preço por peça?"));
let percentualPerda = parseFloat(prompt("qual é o percentual da perda?"));

//processamento
let cobertura = (larguraPeca * comprimentoPeca);
let areaPiso = (larguraP * comprimentoP);
let arePerda = areaPiso + (areaPiso * percentualPerda/100);
let quantidade = (areaPiso / cobertura);
let custo = (preco * quantidade); 
//saída
alert("a área da peça é de " + cobertura + " metros quadrados");
alert("A área do piso é de " + areaPiso.toFixed(2) + " metros quadrados");
alert("A área com perda é " + arePerda.toFixed(2) + " metros quadrados");
alert("será necessário uma quantidade de " + quantidade + " peças");
alert("o custo total será de R$" + custo.toFixed(2));