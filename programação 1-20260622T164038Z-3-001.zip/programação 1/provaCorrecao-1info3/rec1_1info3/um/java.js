let area = parseFloat(prompt("qual o total da área irrigada?(em metros quadrados)"));
let quantidade = parseFloat(prompt("qual a quantidade total de água utilizada?(em litros)"));
let areaSetor = parseFloat(prompt("qual é a área do setor?(em metros quadrados)"));

let consumo = (quantidade / area);
let quantidadeSetor = (quantidade * areaSetor);
let diferenca = (quantidadeSetor - 500);

alert("o consumo de água por metro quadrado é "+consumo.toFixed(2)+" litros");
alert("a quantidade de água utilizada no setor foi de "+quantidadeSetor.toFixed(2)+" litros por metros quadrados");
alert("a diferença entre o consumo d'água e 500 litros é de "+diferenca.toFixed(2)+" litros")