let paginasTotais = parseInt(prompt("qual a quantidade total de páginas a serem escritas?"));
let digitadores = parseint(prompt("quantos digitadores iram escrever?"));
let tempoAtual = parseInt(prompt("digite o tempo estimado(por horas)"));
let novosDigitadores = parseInt(prompt("quantos novos digitadores iram ajudar?"));

let produtividadeEquipe = paginasTotais/tempoAtual;
let produtividadeIndividual = produtividadeEquipe/digitadores;
let totalDigitadores = digitadores + novosDigitadores;
let novaProdutividade = produtividadeEquipe * novosDigitadores
let novoTempo = paginasTotais/novaProdutividade;

alert("quantidade média de páginas por hora da equipe:" +produtividadeEquipe.toFixed(2));
alert("novo número total de digitadores é")