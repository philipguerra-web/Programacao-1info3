let a = 5;
let b = 3;

if(a + b ==3){ 
    alert("o resultado é 3");
}else if (a == 4){
    alert("o valor de a é 4");
}else if (b ==3){
    alert("o valor de b é 3");
}else{
    alert("nenhuma das condições acima");
}


let nome = "Daniel";

if(nome != undefined && nome == "Joaquim"){
    console.log("nome está definido");
}else if(nome == "Daniel" && nome.length >5){
    console.log("seu nome é daniel");
}