let idade = parseInt(prompt("registre sua idade"));

if (idade == 19) {
  console.log("a idade é = 19");
  alert("a idade é = 19");
} else {
  console.log("a idade não é = 19");
  alert("a idade não é = 19");
}

if (idade > 25) {
  console.log(" a idade é maior que 25");
  alert("a idade é maior que 15");
} else {
  console.log("a idade não é maior que 25!");
  alert("a idade não é maior que 25");
}

let nome = "Matheus";

if (nome == "Matheus" && idade > 18) {
  console.log("liberado!");
} else {
  console.log("não liberado");
}

let passaporte = true;
if ((nome == "Matheus" && idade > 30) || passaporte == true) {
  console.log("liberado");
  alert("passaporte aceito");
} else {
  console.log("negado!");
  alert("passaporte negado!");
}
