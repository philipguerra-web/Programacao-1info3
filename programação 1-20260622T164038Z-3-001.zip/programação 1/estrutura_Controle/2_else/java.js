let nome = prompt("qual o seu nome?");
if(nome == "joão"){
    alert("seu nome é João");
}else {
   alert("seu nome não é João");
}

let velo = parseFloat(prompt("insira sua velocidade"));
if(velo <= 80 ){
    alert("não foi multado");
}else {
    alert("foi multado");
}