let nota = parseFloat(prompt("digite a sua nota(1 a 10)"));
let frequencia = parseInt(prompt("quantos % de presença você:"));

if(nota >= 6 && frequencia >= 75){
    alert("aprovado");
}else{
    alert("reprovado");
}