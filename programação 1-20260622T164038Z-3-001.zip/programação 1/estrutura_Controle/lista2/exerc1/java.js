let numero1 = parseFloat(prompt("escreva o primeiro número"));
let numero2 = parseFloat(prompt("escreva o segundo número"));
let operacao = prompt("digite a operação (+,-,*,/) ");
let resultado;

if(operacao === "+"){
    resultado = numero1 + numero2;
}else if (operacao === "-"){
    resultado = numero1 - numero2;
}else if (operacao === "*"){
    resultado = numero1 * numero2;
}else if(operacao === "/"){
    resultado = numero1 / numero2;
}else{
    alert("operação inválida");
}
alert("resultado:" + resultado.toFixed(2));