let salario = parseFloat(prompt("digite o seu salário"));
let imposto;


if(salario <= 2500){
    imposto = 0;
}else if(salario > 2500 && salario <= 5000){
    imposto = salario * 0.15;
}else if(salario > 5000){
    imposto = salario * 0.27
}else{
    imposto = ("digite um  valor valído");
}
alert("o seu valor do imposto será de R$"+imposto);