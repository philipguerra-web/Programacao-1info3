let idade = parseInt(prompt("informe sua idade"));
let categoria;

if(idade <= 12){
    categoria = "infantil";
}else if(13>=idade<17){
    categoria = "juvenil";
}else{
    categoria = "adulto";
}
alert("sua classificação seŕa "+categoria);