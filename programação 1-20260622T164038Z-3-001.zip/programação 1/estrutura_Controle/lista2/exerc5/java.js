let idade = parseInt(prompt("digite sua idade:"));
let entradaPreco = parseFloat(prompt("digite o valor da passagem:"));
let meia = (entradaPreco/2);

if(idade <= 12){
 alert("a criança vai pagar metade, R$ " + meia.toFixed(2));
}else{
    alert("não vai pagar metade, marmanjo veio desse >:/");
}