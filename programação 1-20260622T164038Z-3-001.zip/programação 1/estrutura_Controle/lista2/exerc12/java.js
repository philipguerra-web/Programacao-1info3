let nota1 = parseFloat(prompt("informe a primeira nota"));
let nota2 = parseFloat(prompt("informe a segunda nota"));
let media = ((nota1 + nota2)/ 2);

if(media >= 7){
    alert("aprovado");
}else if(media >= 5 && media <= 6.9){
    alert("recuperção");
}else{
    alert("reprovado");
}
