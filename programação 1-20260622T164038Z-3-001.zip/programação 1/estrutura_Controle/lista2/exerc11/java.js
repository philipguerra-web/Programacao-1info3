let consumo = parseFloat(prompt("informe o consumo mensal de água (em m3):"));
let conta;

if(consumo <= 10){
    conta = 30;
}else if(consumo > 10 && consumo <= 25){
    conta = 50;
}else{
    conta = 80;
}alert("sua conta vai ser de R$"+conta.toFixed(2));