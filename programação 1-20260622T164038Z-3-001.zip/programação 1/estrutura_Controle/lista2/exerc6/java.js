let saldo = parseFloat(prompt("digite o seu saldo"));

if(saldo <= 500){
    alert("nenhum crédito");
}else if(saldo >= 500 && saldo <= 1000){
    alert("receberá um crédito de 30%, seu novo saldo é R$"+(saldo+(0.3*saldo)).toFixed(2));
}else{
    alert("receberá um crédito de 50%, seu novo saldo é R$"+(saldo+(0.5*saldo)).toFixed(2));
}