let A = parseFloat(prompt("digite o lado A:"));
let B = parseFloat(prompt("digite o lado B"));
let C = parseFloat(prompt("digite o lado C"));

if(A == B && A == C){
    
}