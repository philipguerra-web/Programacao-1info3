let lado1 = parseFloat(prompt("digite o primeiro lado"));
let lado2 = parseFloat(prompt("digite o segudndo lado"));
let lado3 = parseFloat(prompt("digite o terceiro lado"));

let soma = lado1 + lado2 && lado1 + lado3 && lado2 + lado3
//regra: a soma de qualquer dos lados deve ser maior que o terceiro.

if(lado3 > soma){
    alert("não forma um triangulo");
}else{
    alert("forma um triangulo");
}