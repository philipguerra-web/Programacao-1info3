let peso = parseFloat(prompt("informe o peso do produto(em kg):"));
let frete;

if(peso <= 5){
    frete = 20;
}else if(peso <= 20){
    frete = 50;
}else{
    frete = 100
}alert("seu frete vai ser de R$"+frete.toFixed(2));
