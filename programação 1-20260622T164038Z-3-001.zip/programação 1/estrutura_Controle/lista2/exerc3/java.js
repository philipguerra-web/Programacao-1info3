let usuario = prompt(" digite o nome de usuário:");
let senha = prompt("digite a sua senha");

if(usuario === "Philip" && senha === "6767"){
      alert("acesso valido");
}else{
    alert("acesso negado");
}