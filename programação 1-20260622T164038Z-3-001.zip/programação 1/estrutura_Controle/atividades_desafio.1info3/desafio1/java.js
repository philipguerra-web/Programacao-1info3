//entrada

let areaTotal = parseFloat(prompt("digite a área total a ser pintada(em metros quadrados):"));
let rendimentoTinta = parseFloat(prompt("digite a quantidade em metros quadrados por litro que a tinta cobre:"));
let volumeTinta = parseFloat(prompt("digite o volume da lata de tinta(em litros):"));
let quantidadeHoras = parseFloat(prompt("quanto tempo foi estimado para a execução do trabalho?"));
let quantidadePintores = parseInt(prompt("quantos pintores foram contratados?"));
let valorHora = parseFloat(prompt("quanto o pintor cobra por hora?"));
let valorReservado = parseFloat(prompt("digite o orçamento máximo que a família tem disponível:"));
let preco = parseFloat(prompt("digite o preço da lata de tinta(em reais)"));
let saldo;
//processamento

let litrosTinta = (Math.ceil(areaTotal/rendimentoTinta));
let latasTinta = (Math.ceil(litrosTinta/volumeTinta));
let custoLata = (latasTinta*preco);
let custoEquipe = (quantidadeHoras * quantidadePintores * valorHora);
custoTotal = (custoEquipe*custoLata);

if(valorReservado >= custoTotal){
    custoTotal+(custoTotal*0.05);
    saldo = 
}