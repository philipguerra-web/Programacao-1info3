let altura = parseFloat(prompt("qual a sua altura?"));
let sexo = prompt("qual o seu sexo?(digite m ou f)");
let pesoIdeal;

if (sexo == "m") {
    pesoIdeal = (72.7 * altura) - 58;
} else if(sexo == "f"){
    pesoIdeal = (62.1 * altura) - 44.7;
}else
    alert("sexo inválido! digite m ou f.");
    
alert("seu peso ideal é de " + pesoIdeal.toFixed(2) + " kg");