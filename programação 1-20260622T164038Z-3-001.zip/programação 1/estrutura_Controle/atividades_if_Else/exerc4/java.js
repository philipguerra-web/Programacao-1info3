let idade = parseInt(prompt("qual a idade do usuário?"));
let CNH = prompt("o usuário possui CNH?(digite sim ou não");

if(idade => 18 && CNH == false) {
    alert("o usuário é de maior, mas não possui CNH");
}else if (idade => 18 && CNH == true){
    alert("o usuário é maior de idade e possui CNH");
} else{
    alert("o usuário não é de maior e não possui CNH");
}