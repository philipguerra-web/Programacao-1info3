let salario = parseFloat(prompt("digite o seu salário atual:"));
let salarioNovo;

if (salario < 1500) {
  salarioNovo = salario * 1.15;
} else if (salario >= 1500 && salario <= 3000) {
  salarioNovo = salario * 1.1;
} else {
  salarioNovo = salario * 1.05;
}
alert("o seu novo salário é de R$" + salarioNovo.toFixed(2));
