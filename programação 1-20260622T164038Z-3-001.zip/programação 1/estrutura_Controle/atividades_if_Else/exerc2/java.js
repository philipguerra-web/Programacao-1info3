const nome = "Philip";

if(nome == "Philip"){
    console.log("SALDAÇÃO GENERAL PHILIP, LINDÃO!");
}