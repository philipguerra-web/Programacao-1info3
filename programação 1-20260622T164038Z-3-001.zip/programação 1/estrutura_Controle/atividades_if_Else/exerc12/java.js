let preco = parseFloat(prompt("digite o preço do produto desejado :"));
let origem = parseInt(prompt("digite o número de origem de seu produto (de 1 a 5):"));

if(origem == 1){
    alert("o seu produto vem do Sul e seu preço será de R$"+preco.toFixed(2));
}else if(origem == 2){
    alert("o seu produto vem do Sudeste e seu preço será de R$"+preco.toFixed(2));
}else if(origem==3){
    alert("o seu produto vem do Centro-Oeste e seu preço será de R$"+preco.toFixed(2));
}else if(origem==4){
    alert("o seu produto vem do Norte e seu preço será de R$"+preco.toFixed(2));
}else if(origem == 5){
    alert("o seu produto vem do Nordeste e seu preço será de R$"+preco.toFixed(2));
}else{
    alert
}alert("o codigo de origem está incorreto, por favor digite número de 1 a 5.");