let velo = parseFloat(prompt("insira sua velocidade"));
if (velo <= 80) {
  alert("sua velocidade está abaixo da máxima permitida");
} else {
  alert("sua velocidade está acima da máxima permitida");
}
