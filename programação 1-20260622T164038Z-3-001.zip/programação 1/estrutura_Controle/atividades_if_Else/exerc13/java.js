let codigo = parseInt(prompt("digite o código do produto(de 1 a 4):"));
let quantidade = parseInt(prompt("digite a quantidade de produtos que você deseja:"));
let preco;
let descricao;

if(codigo == 1){
    preco = 125.48;
    descricao = "Informáticas para concursos";
}else if (codigo == 2){
    preco = 108.36;
    descricao = "Java como Programar";
}else if (codigo == 3){
    preco = 99,99;
    descricao = "lógica de programação";
}else if(codigo == 4){
    preco = 215.67;
    descricao = "Fundamentos de Programação";
}else{
    alert("o valor do código está incorreto, por favor insira valores de 1 a 4.")
}

alert("a descrição do seu produto é "+descricao+" e o gasto nessa compra foi de R$"+quantidade*preco.toFixed(2));
