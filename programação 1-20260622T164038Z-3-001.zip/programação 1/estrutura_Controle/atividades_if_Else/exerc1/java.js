let idade = prompt("qual é sua idade?");

if(idade => 18){
    console.log("pode entrar");
}