let vInicial = parseInt(prompt("informe o valor inicial do relogio(em Kwh)"));
let vFinal = parseInt(prompt("informe o valor final do relogio(em Kwh)"));
let valorKwh = parseFloat(prompt("qual o valor do consumo por Kwh em até 150?(em reais)"));
let consumo = vFinal - vInicial;
let fatura;

if(consumo<=150){
    fatura=consumo*valorKwh;
}else{
    let
}

