let quantidadeDinheiro = parseFloat(prompt("digite a quantidade de dinheiro em caixa:"));
let quantidadeProduto = parseInt(prompt("digite a quantidade de produto:"));
let valorProduto = parseFloat(prompt("digite o valor de cada produto:"));
let valor = quantidadeDinheiro*quantidadeProduto;
let pagamento;
let valorFinal;

if(valor > (quantidadeDinheiro* 0.8)){
    valorFinal=valor*1.1;
    pagamento = "a prazo(3x)";
}else {
    valorFinal = valor * 0.95;
    formaPagamento = "á vista";
}

alert("forma de pagamento: " + formaPagamento);
alert("valor total a pagar: R$" + valorFinal.toFixed(2));