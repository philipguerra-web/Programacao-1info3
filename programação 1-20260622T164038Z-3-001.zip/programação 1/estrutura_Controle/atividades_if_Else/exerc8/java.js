let tipo = prompt("qual tipo de combustivel vocẽ deseja? escreva G(gasolina) ou E(etanol)").toUpperCase();
let capacidade = parseFloat(prompt("digete a capacidade do tanque(em litros):"));

const G = 5.65;
const E = 4.38;

let valorTotal;

if(tipo === "G"){
    valorTotal = capacidade*G;
}else if (tipo === "E"){
    valorTotal = capacidade*E;
}else {
    alert("tipo de combustível inválido! digite G ou E.");
}
if(valorTotal != undefined){
    alert("a capacidade do tanque é de "+valorTotal.toFixed(2)+" litros")
}
