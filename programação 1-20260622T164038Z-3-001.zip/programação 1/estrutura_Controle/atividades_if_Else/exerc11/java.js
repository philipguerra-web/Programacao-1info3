let T = parseFloat(prompt("escreva a temperatura que está na sala"));

if (T < 100){
    alert("a temperatura está muito baixa");
}else if (T >= 100 && T <= 200){
    alert("a temperatura está baixa");
}else if (T > 200 && T <  500){
    alert("a temperatura está normal");
}else{
    alert("a temperatura está muito alta");
}
