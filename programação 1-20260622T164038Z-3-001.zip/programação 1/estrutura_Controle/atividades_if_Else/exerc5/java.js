let valorA = parseFloat(prompt("digite o valor de A"));
let valorB = parseFloat(prompt("digite o valor de B"));
let resultado;

if(valorA > valorB){
     resultado = ("é maior");
}else {
     resultado = ("é menor");
} 
alert(resultado);